# Web-Design-Final-Project

 Working on this portfolio website was a fun but challenging experience. At first, I just wanted something simple to show my projects, but I quickly realized how much detail goes into making a site look clean and actually feel personal. I had to think about layout, colors, and how to keep everything responsive — and honestly, I ended up learning a lot more than I expected. 

One of the biggest things I learned was how important small design decisions are, like spacing and image sizing. I kept tweaking things to get the images to sit just right or to make the layout feel balanced. It definitely took some trial and error, but I’m happy with how it turned out. It’s cool to look at something and know you built it from scratch.
